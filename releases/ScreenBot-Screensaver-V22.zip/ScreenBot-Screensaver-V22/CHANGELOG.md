# Changelog

## V22

- Added opt-in Live Sky mode with local time-of-day and lunar rendering, optional weather-aware animations, KDE settings, asynchronous weather updates, and an offline cache.
- Added all 896 country/city choices from `countries_and_cities.txt` to KDE Settings; the selected place is resolved and weather is fetched through Open-Meteo without IP-based location lookup.
- Added automated astronomy, weather mapping, network/cache, and offscreen rendering coverage. Existing manual weather effects remain available when Live Sky is off.
- Published as a ZIP release with an installation guide and release notes.

## V21

- Removed the relationship storyline, its character and message content, story-specific animation phases, and its KDE Settings option.
- Kept BobOS 2.0 running through the standard phone adventure, with fictional BobChat, Maps, Weather, Calendar, App Store, and game screens.
- Preserved the phone preview, staged KDE Apply/Discard behavior for remaining settings, and the real KDE password-lock priority.
- Updated offscreen tests to cover the full BobOS sequence and animated rendering for the retained phone apps.

## V20

- Expanded BobOS 2.0 with additional fictional phone apps and longer animated interactions. V21 retains the ordinary BobChat, Maps, Weather, Calendar, and App Store simulations.

## V19

- Replaced the AI Backpack and tiny laptop with Bob's Phone while keeping Bob head-only.
- Rebuilt BobOS as a scripted, animated phone experience with home, Browser, Files, Terminal, Games, Settings, notification, boot, shutdown, and camera-zoom phases. All content is painted locally; it never opens apps, files, websites, or commands.
- Renamed the KDE control to Enable Bob's Phone and added a lock-safe Preview full adventure button. Preview skips the activation delay but still yields to the configured KDE password lock.
- Added automated timeline and offscreen rendering checks for the complete preview sequence, lock priority, theme return, and app interactions.

## V18

- Added separate AI Backpack and BobOS switches, both enabled by default; disabling the backpack disables BobOS controls without changing the saved BobOS choice.
- Added an activation delay from 1 to 30 minutes, measured from the screensaver's first visible frame, plus an optional fictional Wi-Fi connection animation.
- Added fictional BobOS adventures with a close-and-pack sequence and follow-up timing that waits at least five minutes after each adventure.
- Kept all BobOS visuals inside the screensaver and suppressed them once the configured KDE password-lock deadline is reached.

## V17

- Added a remembered-choice checkbox to the active-agent Yes/No dialog.
- Added persistent Always ask, Always start screensaver, and Don't start screensaver while agents are running settings, plus a reset action.
- Made uncertain detection and prompt timeouts cancel automatic launches safely; manual launches bypass the agent prompt.
- Kept the prompt choice separate from KDE's staged settings so the Settings module's Apply and Discard behavior remains intact.
