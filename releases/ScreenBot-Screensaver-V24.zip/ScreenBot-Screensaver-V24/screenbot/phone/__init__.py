"""BobOS phone rendering components."""
