#pragma once
#include <KQuickConfigModule>
#include <QString>
#include "locationsearch.h"

class QProcess;
class QQuickItem;
class QSettings;
class QUrl;

class ScreenBotKcm : public KQuickConfigModule {
    Q_OBJECT
    Q_PROPERTY(QStringList modifiedSections READ modifiedSections NOTIFY modifiedSectionsChanged)
    Q_PROPERTY(bool previewRunning READ previewRunning NOTIFY previewRunningChanged)
    Q_PROPERTY(QString previewError READ previewError NOTIFY previewErrorChanged)
    Q_PROPERTY(QString theme READ theme WRITE setTheme NOTIFY themeChanged)
    Q_PROPERTY(QString photoFolder READ photoFolder WRITE setPhotoFolder NOTIFY photoFolderChanged)
    Q_PROPERTY(bool photoIncludeSubfolders READ photoIncludeSubfolders WRITE setPhotoIncludeSubfolders NOTIFY photoIncludeSubfoldersChanged)
    Q_PROPERTY(int photoInterval READ photoInterval WRITE setPhotoInterval NOTIFY photoIntervalChanged)
    Q_PROPERTY(QString photoOrder READ photoOrder WRITE setPhotoOrder NOTIFY photoOrderChanged)
    Q_PROPERTY(QString photoFit READ photoFit WRITE setPhotoFit NOTIFY photoFitChanged)
    Q_PROPERTY(bool passwordLock READ passwordLock WRITE setPasswordLock NOTIFY passwordLockChanged)
    Q_PROPERTY(int lockMinutes READ lockMinutes WRITE setLockMinutes NOTIFY lockMinutesChanged)
    Q_PROPERTY(bool showTimer READ showTimer WRITE setShowTimer NOTIFY showTimerChanged)
    Q_PROPERTY(bool nowPlayingEnabled READ nowPlayingEnabled WRITE setNowPlayingEnabled NOTIFY nowPlayingEnabledChanged)
    Q_PROPERTY(bool factsEnabled READ factsEnabled WRITE setFactsEnabled NOTIFY factsEnabledChanged)
    Q_PROPERTY(int factsIntervalMinutes READ factsIntervalMinutes WRITE setFactsIntervalMinutes NOTIFY factsIntervalMinutesChanged)
    Q_PROPERTY(QString factsContentMode READ factsContentMode WRITE setFactsContentMode NOTIFY factsContentModeChanged)

    Q_PROPERTY(bool ambientSoundEnabled READ ambientSoundEnabled WRITE setAmbientSoundEnabled NOTIFY ambientSoundEnabledChanged)
    Q_PROPERTY(int ambientSoundVolume READ ambientSoundVolume WRITE setAmbientSoundVolume NOTIFY ambientSoundVolumeChanged)
    Q_PROPERTY(QString ambientSoundMode READ ambientSoundMode WRITE setAmbientSoundMode NOTIFY ambientSoundModeChanged)
    Q_PROPERTY(bool ambientQuietHours READ ambientQuietHours WRITE setAmbientQuietHours NOTIFY ambientQuietHoursChanged)
    Q_PROPERTY(bool clockVisible READ clockVisible WRITE setClockVisible NOTIFY clockVisibleChanged)
    Q_PROPERTY(QString clockFormat READ clockFormat WRITE setClockFormat NOTIFY clockFormatChanged)
    Q_PROPERTY(bool showDate READ showDate WRITE setShowDate NOTIFY showDateChanged)
    Q_PROPERTY(QString clockPosition READ clockPosition WRITE setClockPosition NOTIFY clockPositionChanged)
    Q_PROPERTY(int clockFontSize READ clockFontSize WRITE setClockFontSize NOTIFY clockFontSizeChanged)
    Q_PROPERTY(bool rainEnabled READ rainEnabled WRITE setRainEnabled NOTIFY rainEnabledChanged)
    Q_PROPERTY(bool snowEnabled READ snowEnabled WRITE setSnowEnabled NOTIFY snowEnabledChanged)
    Q_PROPERTY(bool thunderstormsEnabled READ thunderstormsEnabled WRITE setThunderstormsEnabled NOTIFY thunderstormsEnabledChanged)
    Q_PROPERTY(bool fogEnabled READ fogEnabled WRITE setFogEnabled NOTIFY fogEnabledChanged)
    Q_PROPERTY(bool shootingStarsEnabled READ shootingStarsEnabled WRITE setShootingStarsEnabled NOTIFY shootingStarsEnabledChanged)
    Q_PROPERTY(bool bobWeatherEnabled READ bobWeatherEnabled WRITE setBobWeatherEnabled NOTIFY bobWeatherEnabledChanged)
    Q_PROPERTY(QString bobName READ bobName WRITE setBobName NOTIFY bobNameChanged)
    Q_PROPERTY(QString bobColorPreset READ bobColorPreset WRITE setBobColorPreset NOTIFY bobColorPresetChanged)
    Q_PROPERTY(QString bobCustomColor READ bobCustomColor WRITE setBobCustomColor NOTIFY bobCustomColorChanged)
    Q_PROPERTY(QString bobAccessory READ bobAccessory WRITE setBobAccessory NOTIFY bobAccessoryChanged)
    Q_PROPERTY(bool liveSkyEnabled READ liveSkyEnabled WRITE setLiveSkyEnabled NOTIFY liveSkyEnabledChanged)
    Q_PROPERTY(QStringList liveSkyLocations READ liveSkyLocations CONSTANT)
    Q_PROPERTY(QString liveSkyLocation READ liveSkyLocation WRITE setLiveSkyLocation NOTIFY liveSkyLocationChanged)
    Q_PROPERTY(LocationSearch *locationSearch READ locationSearch CONSTANT)
    Q_PROPERTY(QVariantMap liveSkyPlace READ liveSkyPlace NOTIFY liveSkyLocationChanged)
    Q_PROPERTY(QString liveSkyUnits READ liveSkyUnits WRITE setLiveSkyUnits NOTIFY liveSkyUnitsChanged)
    Q_PROPERTY(int liveSkyInterval READ liveSkyInterval WRITE setLiveSkyInterval NOTIFY liveSkyIntervalChanged)
    Q_PROPERTY(bool liveSkyConditions READ liveSkyConditions WRITE setLiveSkyConditions NOTIFY liveSkyConditionsChanged)
    Q_PROPERTY(bool seasonalEnabled READ seasonalEnabled WRITE setSeasonalEnabled NOTIFY seasonalEnabledChanged)
    Q_PROPERTY(bool seasonalNewYearEnabled READ seasonalNewYearEnabled WRITE setSeasonalNewYearEnabled NOTIFY seasonalNewYearEnabledChanged)
    Q_PROPERTY(bool seasonalLunarNewYearEnabled READ seasonalLunarNewYearEnabled WRITE setSeasonalLunarNewYearEnabled NOTIFY seasonalLunarNewYearEnabledChanged)
    Q_PROPERTY(bool seasonalValentinesEnabled READ seasonalValentinesEnabled WRITE setSeasonalValentinesEnabled NOTIFY seasonalValentinesEnabledChanged)
    Q_PROPERTY(bool seasonalSpringEnabled READ seasonalSpringEnabled WRITE setSeasonalSpringEnabled NOTIFY seasonalSpringEnabledChanged)
    Q_PROPERTY(bool seasonalHalloweenEnabled READ seasonalHalloweenEnabled WRITE setSeasonalHalloweenEnabled NOTIFY seasonalHalloweenEnabledChanged)
    Q_PROPERTY(bool seasonalWinterHolidaysEnabled READ seasonalWinterHolidaysEnabled WRITE setSeasonalWinterHolidaysEnabled NOTIFY seasonalWinterHolidaysEnabledChanged)
    Q_PROPERTY(bool seasonalBirthdayEnabled READ seasonalBirthdayEnabled WRITE setSeasonalBirthdayEnabled NOTIFY seasonalBirthdayEnabledChanged)
    Q_PROPERTY(QString seasonalBirthdayDate READ seasonalBirthdayDate WRITE setSeasonalBirthdayDate NOTIFY seasonalBirthdayDateChanged)
    Q_PROPERTY(QString seasonalBirthdayName READ seasonalBirthdayName WRITE setSeasonalBirthdayName NOTIFY seasonalBirthdayNameChanged)
    Q_PROPERTY(QString agentDetectionMode READ agentDetectionMode WRITE setAgentDetectionMode NOTIFY agentDetectionModeChanged)
    Q_PROPERTY(bool agentStatusEnabled READ agentStatusEnabled WRITE setAgentStatusEnabled NOTIFY agentStatusEnabledChanged)
    Q_PROPERTY(int agentPromptTimeout READ agentPromptTimeout WRITE setAgentPromptTimeout NOTIFY agentPromptTimeoutChanged)
    Q_PROPERTY(QString agentPromptTimeoutAction READ agentPromptTimeoutAction WRITE setAgentPromptTimeoutAction NOTIFY agentPromptTimeoutActionChanged)
    Q_PROPERTY(bool phoneEnabled READ phoneEnabled WRITE setPhoneEnabled NOTIFY phoneEnabledChanged)
    Q_PROPERTY(bool bobosEnabled READ bobosEnabled WRITE setBobosEnabled NOTIFY bobosEnabledChanged)
    Q_PROPERTY(int bobosActivationDelay READ bobosActivationDelay WRITE setBobosActivationDelay NOTIFY bobosActivationDelayChanged)
    Q_PROPERTY(bool showWifiAnimation READ showWifiAnimation WRITE setShowWifiAnimation NOTIFY showWifiAnimationChanged)
    Q_PROPERTY(QString performanceMode READ performanceMode WRITE setPerformanceMode NOTIFY performanceModeChanged)
    Q_PROPERTY(bool reduceMotion READ reduceMotion WRITE setReduceMotion NOTIFY reduceMotionChanged)
    Q_PROPERTY(QString burnInProtection READ burnInProtection WRITE setBurnInProtection NOTIFY burnInProtectionChanged)
public:
    ScreenBotKcm(QObject *parent, const KPluginMetaData &data);
    QStringList modifiedSections() const;
    Q_INVOKABLE bool sectionExpanded(const QString &section) const;
    Q_INVOKABLE void setSectionExpanded(const QString &section, bool expanded);
    Q_INVOKABLE void setPhotoFolderUrl(const QUrl &url);
    bool previewRunning() const { return m_previewProcess != nullptr; }
    QString previewError() const { return m_previewError; }
    Q_INVOKABLE void previewTheme(QQuickItem *source = nullptr);
    QString theme() const { return m_theme; }
    QString photoFolder() const { return m_photoFolder; }
    bool photoIncludeSubfolders() const { return m_photoIncludeSubfolders; }
    int photoInterval() const { return m_photoInterval; }
    QString photoOrder() const { return m_photoOrder; }
    QString photoFit() const { return m_photoFit; }
    bool passwordLock() const { return m_passwordLock; }
    int lockMinutes() const { return m_lockMinutes; }
    bool showTimer() const { return m_showTimer; }
    bool nowPlayingEnabled() const { return m_nowPlayingEnabled; }
    bool factsEnabled() const { return m_factsEnabled; }
    int factsIntervalMinutes() const { return m_factsIntervalMinutes; }
    QString factsContentMode() const { return m_factsContentMode; }

    bool ambientSoundEnabled() const { return m_ambientSoundEnabled; }
    int ambientSoundVolume() const { return m_ambientSoundVolume; }
    QString ambientSoundMode() const { return m_ambientSoundMode; }
    bool ambientQuietHours() const { return m_ambientQuietHours; }
    bool clockVisible() const { return m_clockVisible; }
    QString clockFormat() const { return m_clockFormat; }
    bool showDate() const { return m_showDate; }
    QString clockPosition() const { return m_clockPosition; }
    int clockFontSize() const { return m_clockFontSize; }
    bool rainEnabled() const { return m_rainEnabled; }
    bool snowEnabled() const { return m_snowEnabled; }
    bool thunderstormsEnabled() const { return m_thunderstormsEnabled; }
    bool fogEnabled() const { return m_fogEnabled; }
    bool shootingStarsEnabled() const { return m_shootingStarsEnabled; }
    bool bobWeatherEnabled() const { return m_bobWeatherEnabled; }
    QString bobName() const { return m_bobName; }
    QString bobColorPreset() const { return m_bobColorPreset; }
    QString bobCustomColor() const { return m_bobCustomColor; }
    QString bobAccessory() const { return m_bobAccessory; }
    bool liveSkyEnabled() const { return m_liveSkyEnabled; }
    QStringList liveSkyLocations() const { return m_liveSkyLocations; }
    QString liveSkyLocation() const { return m_liveSkyLocation; }
    LocationSearch *locationSearch() { return &m_locationSearch; }
    QVariantMap liveSkyPlace() const { return m_liveSkyPlace; }
    Q_INVOKABLE void selectLiveSkyPlace(int index);
    QString liveSkyUnits() const { return m_liveSkyUnits; }
    int liveSkyInterval() const { return m_liveSkyInterval; }
    bool liveSkyConditions() const { return m_liveSkyConditions; }
    bool seasonalEnabled() const { return m_seasonalEnabled; }
    bool seasonalNewYearEnabled() const { return m_seasonalNewYearEnabled; }
    bool seasonalLunarNewYearEnabled() const { return m_seasonalLunarNewYearEnabled; }
    bool seasonalValentinesEnabled() const { return m_seasonalValentinesEnabled; }
    bool seasonalSpringEnabled() const { return m_seasonalSpringEnabled; }
    bool seasonalHalloweenEnabled() const { return m_seasonalHalloweenEnabled; }
    bool seasonalWinterHolidaysEnabled() const { return m_seasonalWinterHolidaysEnabled; }
    bool seasonalBirthdayEnabled() const { return m_seasonalBirthdayEnabled; }
    QString seasonalBirthdayDate() const { return m_seasonalBirthdayDate; }
    QString seasonalBirthdayName() const { return m_seasonalBirthdayName; }
    QString agentDetectionMode() const { return m_agentDetectionMode; }
    bool agentStatusEnabled() const { return m_agentStatusEnabled; }
    int agentPromptTimeout() const { return m_agentPromptTimeout; }
    QString agentPromptTimeoutAction() const { return m_agentPromptTimeoutAction; }
    bool phoneEnabled() const { return m_phoneEnabled; }
    bool bobosEnabled() const { return m_bobosEnabled; }
    int bobosActivationDelay() const { return m_bobosActivationDelay; }
    bool showWifiAnimation() const { return m_showWifiAnimation; }
    QString performanceMode() const { return m_performanceMode; }
    bool reduceMotion() const { return m_reduceMotion; }
    QString burnInProtection() const { return m_burnInProtection; }
    void setTheme(const QString &value);
    void setPhotoFolder(const QString &value);
    void setPhotoIncludeSubfolders(bool value);
    void setPhotoInterval(int value);
    void setPhotoOrder(const QString &value);
    void setPhotoFit(const QString &value);
    void setPasswordLock(bool value);
    void setLockMinutes(int value);
    void setShowTimer(bool value);
    void setClockVisible(bool value);
    void setNowPlayingEnabled(bool value);
    void setFactsEnabled(bool value);
    void setFactsIntervalMinutes(int value);
    void setFactsContentMode(const QString &value);

    void setAmbientSoundEnabled(bool value);
    void setAmbientSoundVolume(int value);
    void setAmbientSoundMode(const QString &value);
    void setAmbientQuietHours(bool value);
    void setClockFormat(const QString &value);
    void setShowDate(bool value);
    void setClockPosition(const QString &value);
    void setClockFontSize(int value);
    void setRainEnabled(bool value);
    void setSnowEnabled(bool value);
    void setThunderstormsEnabled(bool value);
    void setFogEnabled(bool value);
    void setShootingStarsEnabled(bool value);
    void setBobWeatherEnabled(bool value);
    void setBobName(const QString &value);
    void setBobColorPreset(const QString &value);
    void setBobCustomColor(const QString &value);
    void setBobAccessory(const QString &value);
    void setLiveSkyEnabled(bool value);
    void setLiveSkyLocation(const QString &value);
    void setLiveSkyUnits(const QString &value);
    void setLiveSkyInterval(int value);
    void setLiveSkyConditions(bool value);
    void setSeasonalEnabled(bool value);
    void setSeasonalNewYearEnabled(bool value);
    void setSeasonalLunarNewYearEnabled(bool value);
    void setSeasonalValentinesEnabled(bool value);
    void setSeasonalSpringEnabled(bool value);
    void setSeasonalHalloweenEnabled(bool value);
    void setSeasonalWinterHolidaysEnabled(bool value);
    void setSeasonalBirthdayEnabled(bool value);
    void setSeasonalBirthdayDate(const QString &value);
    void setSeasonalBirthdayName(const QString &value);
    void setAgentDetectionMode(const QString &value);
    void setAgentStatusEnabled(bool value);
    void setAgentPromptTimeout(int value);
    void setAgentPromptTimeoutAction(const QString &value);
    Q_INVOKABLE void resetRememberedAgentChoice();
    Q_INVOKABLE void previewBobOS(bool showWifiAnimation);
    void setPhoneEnabled(bool value);
    void setBobosEnabled(bool value);
    void setBobosActivationDelay(int value);
    void setShowWifiAnimation(bool value);
    void setPerformanceMode(const QString &value);
    void setReduceMotion(bool value);
    void setBurnInProtection(const QString &value);
    void load() override;
    void save() override;
Q_SIGNALS:
    void modifiedSectionsChanged();
    void previewRunningChanged();
    void previewErrorChanged();
    void themeChanged();
    void photoFolderChanged();
    void photoIncludeSubfoldersChanged();
    void photoIntervalChanged();
    void photoOrderChanged();
    void photoFitChanged();
    void passwordLockChanged();
    void lockMinutesChanged();
    void showTimerChanged();
    void clockVisibleChanged();
    void nowPlayingEnabledChanged();
    void factsEnabledChanged();
    void factsIntervalMinutesChanged();
    void factsContentModeChanged();

    void ambientSoundEnabledChanged();
    void ambientSoundVolumeChanged();
    void ambientSoundModeChanged();
    void ambientQuietHoursChanged();
    void clockFormatChanged();
    void showDateChanged();
    void clockPositionChanged();
    void clockFontSizeChanged();
    void rainEnabledChanged();
    void snowEnabledChanged();
    void thunderstormsEnabledChanged();
    void fogEnabledChanged();
    void shootingStarsEnabledChanged();
    void bobWeatherEnabledChanged();
    void bobNameChanged();
    void bobColorPresetChanged();
    void bobCustomColorChanged();
    void bobAccessoryChanged();
    void liveSkyEnabledChanged();
    void liveSkyLocationChanged();
    void liveSkyUnitsChanged();
    void liveSkyIntervalChanged();
    void liveSkyConditionsChanged();
    void seasonalEnabledChanged();
    void seasonalNewYearEnabledChanged();
    void seasonalLunarNewYearEnabledChanged();
    void seasonalValentinesEnabledChanged();
    void seasonalSpringEnabledChanged();
    void seasonalHalloweenEnabledChanged();
    void seasonalWinterHolidaysEnabledChanged();
    void seasonalBirthdayEnabledChanged();
    void seasonalBirthdayDateChanged();
    void seasonalBirthdayNameChanged();
    void agentDetectionModeChanged();
    void agentStatusEnabledChanged();
    void agentPromptTimeoutChanged();
    void agentPromptTimeoutActionChanged();
    void phoneEnabledChanged();
    void bobosEnabledChanged();
    void bobosActivationDelayChanged();
    void showWifiAnimationChanged();
    void performanceModeChanged();
    void reduceMotionChanged();
    void burnInProtectionChanged();
private:
    void writeSettings(QSettings &cfg) const;
    void startPreview(bool bobos, bool wifiAnimation, QQuickItem *source = nullptr);
    QProcess *m_previewProcess = nullptr;
    QString m_previewError;
    void checkModified();
    QString m_theme = QStringLiteral("random");
    QString m_photoFolder;
    bool m_photoIncludeSubfolders = false;
    int m_photoInterval = 15;
    QString m_photoOrder = QStringLiteral("name");
    QString m_photoFit = QStringLiteral("fill");
    bool m_passwordLock = false;
    int m_lockMinutes = 2;
    bool m_showTimer = false;
    QString m_savedTheme = QStringLiteral("random");
    QString m_savedPhotoFolder;
    bool m_savedPhotoIncludeSubfolders = false;
    int m_savedPhotoInterval = 15;
    QString m_savedPhotoOrder = QStringLiteral("name");
    QString m_savedPhotoFit = QStringLiteral("fill");
    bool m_savedPasswordLock = false;
    int m_savedLockMinutes = 2;
    bool m_savedShowTimer = false;
    bool m_clockVisible = true;
    bool m_nowPlayingEnabled = false;
    bool m_savedNowPlayingEnabled = false;
    bool m_factsEnabled = true;
    int m_factsIntervalMinutes = 3;
    QString m_factsContentMode = QStringLiteral("facts");
    bool m_savedFactsEnabled = true;
    int m_savedFactsIntervalMinutes = 3;
    QString m_savedFactsContentMode = QStringLiteral("facts");

    bool m_ambientSoundEnabled = false;
    bool m_savedAmbientSoundEnabled = false;
    int m_ambientSoundVolume = 25;
    int m_savedAmbientSoundVolume = 25;
    QString m_ambientSoundMode = QStringLiteral("always");
    QString m_savedAmbientSoundMode = QStringLiteral("always");
    bool m_ambientQuietHours = false;
    bool m_savedAmbientQuietHours = false;
    QString m_clockFormat = QStringLiteral("12h");
    bool m_showDate = false;
    QString m_clockPosition = QStringLiteral("top-center");
    int m_clockFontSize = 48;
    bool m_rainEnabled = false;
    bool m_snowEnabled = false;
    bool m_thunderstormsEnabled = false;
    bool m_fogEnabled = false;
    bool m_shootingStarsEnabled = false;
    bool m_bobWeatherEnabled = true;
    QString m_bobName = QStringLiteral("Bob");
    QString m_bobColorPreset = QStringLiteral("cyan");
    QString m_bobCustomColor = QStringLiteral("#6bf6ff");
    QString m_bobAccessory = QStringLiteral("none");
    bool m_liveSkyEnabled = false;
    QStringList m_liveSkyLocations;
    QString m_liveSkyLocation;
    LocationSearch m_locationSearch;
    QVariantMap m_liveSkyPlace;
    QVariantMap m_savedLiveSkyPlace;
    QString m_liveSkyUnits = QStringLiteral("c");
    int m_liveSkyInterval = 30;
    bool m_liveSkyConditions = true;
    bool m_seasonalEnabled = true;
    bool m_seasonalNewYearEnabled = true;
    bool m_seasonalLunarNewYearEnabled = false;
    bool m_seasonalValentinesEnabled = false;
    bool m_seasonalSpringEnabled = false;
    bool m_seasonalHalloweenEnabled = false;
    bool m_seasonalWinterHolidaysEnabled = false;
    bool m_seasonalBirthdayEnabled = false;
    QString m_seasonalBirthdayDate = QStringLiteral("01-01");
    QString m_seasonalBirthdayName;
    bool m_savedSeasonalEnabled = true;
    bool m_savedSeasonalNewYearEnabled = true;
    bool m_savedSeasonalLunarNewYearEnabled = false;
    bool m_savedSeasonalValentinesEnabled = false;
    bool m_savedSeasonalSpringEnabled = false;
    bool m_savedSeasonalHalloweenEnabled = false;
    bool m_savedSeasonalWinterHolidaysEnabled = false;
    bool m_savedSeasonalBirthdayEnabled = false;
    QString m_savedSeasonalBirthdayDate = QStringLiteral("01-01");
    QString m_savedSeasonalBirthdayName;
    QString m_agentDetectionMode = QStringLiteral("ask");
    bool m_agentStatusEnabled = true;
    int m_agentPromptTimeout = 10;
    QString m_agentPromptTimeoutAction = QStringLiteral("start");
    bool m_savedClockVisible = true;
    QString m_savedClockFormat = QStringLiteral("12h");
    bool m_savedShowDate = false;
    QString m_savedClockPosition = QStringLiteral("top-center");
    int m_savedClockFontSize = 48;
    bool m_savedRainEnabled = false;
    bool m_savedSnowEnabled = false;
    bool m_savedThunderstormsEnabled = false;
    bool m_savedFogEnabled = false;
    bool m_savedShootingStarsEnabled = false;
    bool m_savedBobWeatherEnabled = true;
    QString m_savedBobName = QStringLiteral("Bob");
    QString m_savedBobColorPreset = QStringLiteral("cyan");
    QString m_savedBobCustomColor = QStringLiteral("#6bf6ff");
    QString m_savedBobAccessory = QStringLiteral("none");
    bool m_savedLiveSkyEnabled = false;
    QString m_savedLiveSkyLocation;
    QString m_savedLiveSkyUnits = QStringLiteral("c");
    int m_savedLiveSkyInterval = 30;
    bool m_savedLiveSkyConditions = true;
    QString m_savedAgentDetectionMode = QStringLiteral("ask");
    bool m_savedAgentStatusEnabled = true;
    int m_savedAgentPromptTimeout = 10;
    QString m_savedAgentPromptTimeoutAction = QStringLiteral("start");
    bool m_phoneEnabled = true;
    bool m_bobosEnabled = true;
    int m_bobosActivationDelay = 3;
    bool m_showWifiAnimation = true;
    QString m_performanceMode = QStringLiteral("balanced");
    bool m_reduceMotion = false;
    QString m_burnInProtection = QStringLiteral("standard");
    bool m_savedPhoneEnabled = true;
    bool m_savedBobosEnabled = true;
    int m_savedBobosActivationDelay = 3;
    bool m_savedShowWifiAnimation = true;
    QString m_savedPerformanceMode = QStringLiteral("balanced");
    bool m_savedReduceMotion = false;
    QString m_savedBurnInProtection = QStringLiteral("standard");
};
